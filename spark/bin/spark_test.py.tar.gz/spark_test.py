from pyspark import SparkContext, SparkConf
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import SQLContext
import sys, os
#import threading

### Add python kafka producer
from kafka import KafkaProducer



def check_test(result):
	#print("@@"+str(result))
	producer.send('result', str(result))
	producer.flush()

class DataFusion:
	weightArr = []
	distanceArr = []
	
	def __init__(self):
		self.weightArr = []
		self.distanceArr = []
		self.observedTime = 0
	
	def handler(self, t,rdd):
		records = rdd.collect()
		for record in records:	
			result = record[1]
			self.set(result)
	
	def set(self, data):
		#parsing and check the value in dataArray whether exist or not
		#if exist, fuse()
		#if not,   append 'sensorID and count value' to dataArray
		
		dt = data.split(",") #dt[0]=sensorID dt[1]=count dt[2]=time
		stype, sensorID , count = dt[0][-2], dt[0], dt[1]		
		item = [sensorID[:-2], count]

		if stype =='W':
			if item not in self.distanceArr:
				self.weightArr.append(item)
			else:
				self.fuse(item,stype)
			
		elif stype =='D':
			if item not in self.weightArr:
				self.distanceArr.append(item)
			else:
				self.fuse(item,stype)
			
	def undo(self):
		pass
		
	def fuse(self, item, stype):
		#delete the value and then return result to webserver through kafka
		if stype == 'W':
			self.distanceArr.remove(item)
			producer.send('result', "Product location : "+str(item[0])+" Number of product : "+str(item[1]))
			producer.flush()
		
		elif stype =='D':
			self.weightArr.remove(item)
			producer.send('result', "Product location : "+str(item[0])+" Number of product : "+str(item[1]))
			producer.flush()
		
		

### Create a StremingContext with batch interval of 1sec
if __name__ == "__main__":
	
	producer = KafkaProducer(bootstrap_servers='localhost:9092')	

	sc = SparkContext(appName="Data Fusion edge side")
	ssc = StreamingContext(sc,1)
	sqlContext = SQLContext(sc)

	df = DataFusion()

	### Create kafka streaming with argv(localhost:2181)
	zkQuorum = sys.argv[1]

	ch_zone1 = KafkaUtils.createStream(ssc, zkQuorum, "spark-streaming-consumer1", {"zone1": 2})
	ch_zone1.foreachRDD(df.handler)


	### Start the computation
	ssc.start()

	### Wait for the computation to terminate
	ssc.awaitTermination()
	
	

	'''
	for i in range(10):
		globals()['shelf{}'.format(i)] = KafkaUtils.createStream(ssc, zkQuorum, "spark-streaming-consumer"+str(i), {'shelf{}'.format(i): 1})
		globals()['shelf{}'.format(i)].foreachRDD(test)
	'''

